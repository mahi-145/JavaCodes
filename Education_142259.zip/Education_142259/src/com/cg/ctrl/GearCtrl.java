package com.cg.ctrl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.dto.Gear;

import com.cg.service.GearService;



@Controller
public class GearCtrl {
	
	@Autowired
	GearService serviceGear;
	
	@RequestMapping("/start")
	public String firstPage(Model model)
	{
	Gear gear=new Gear();
	System.out.println("Am I working? yes");
		model.addAttribute("update",gear);
	return "Modify";
	}
	
	@RequestMapping("/EnterUpdatePage")
	public String updatePage(@ModelAttribute("update") Gear gear,Model model)
	{
		/*List<Gear> idList=serviceGear.getQueryId(qId);
		
		System.out.println("Am I working? yes");
		
		if(idList.size()!=0)
		{
			System.out.println("Am I working? yes");*/
			Gear detail = serviceGear.getDetail(gear);
					model.addAttribute("update1",detail);
		return "Show";
		/*}
		else 
			return "noIdExist";*/
	}
	
	
	@ModelAttribute("sme")
	public Map<String,String> map()
	{
	//	System.out.println("Am I working? yes");
		
		Map<String,String> sme=new HashMap<String,String>();
		
		sme.put("Uma","Uma");
		sme.put("Rahul","Rahul");
		
		sme.put("Kavit","Kavit");
		sme.put("Hema","Hema");
		return sme;
}
	@RequestMapping("/EnterUpdatePage1")
	public String updatePageShow(@Valid @ModelAttribute("update1")Gear gear,BindingResult result,Model model)
	{
		System.out.println("Am I working? yes");
		
		if(result.hasErrors()){
			
			return "Show"; 
		}
		serviceGear.updateDetails(gear);
		model.addAttribute("update1",gear);
		return "success";
	}
	
}

