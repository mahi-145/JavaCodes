package com.cg.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.GearDao;
import com.cg.dto.Gear;


@Service
@Transactional
public class GearServiceImpl implements GearService {
	@Autowired
	GearDao dao;
	@Override
	public void updateDetails(Gear gear) {
		// TODO Auto-generated method stub
		dao.updateDetails(gear);
	}
	@Override
	public Gear getDetail(Gear gear) {
		// TODO Auto-generated method stub
		return dao.getDetail(gear);
	}
	@Override
	public List<Gear> getQueryId(int qId) {
		// TODO Auto-generated method stub
		return dao.getQueryId(qId);
	}

}
