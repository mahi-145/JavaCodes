package com.cg.service;

import java.util.List;

import com.cg.dto.Gear;


public interface GearService {
	public void updateDetails(Gear gear);
	public Gear getDetail(Gear gear);
	public List<Gear> getQueryId(int qId);
}
