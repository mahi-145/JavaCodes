package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.dto.Gear;



@Repository
public class GearDaoImpl implements GearDao {
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public void updateDetails(Gear gear) {
		entityManager.merge(gear);
		entityManager.flush();// TODO Auto-generated method stub
		
	}
	@Override
	public Gear getDetail(Gear gear) {
		Gear record=entityManager.find(Gear.class,gear.getQueryId());
		return record;
	}
	@Override
	public List<Gear> getQueryId(int qId) {
		Query q3= entityManager.createQuery("Select emp from Query_Master emp where query_id=:qId");
		q3.setParameter("qId", qId);
		List<Gear> idList=q3.getResultList();
		return idList;
	}


}
