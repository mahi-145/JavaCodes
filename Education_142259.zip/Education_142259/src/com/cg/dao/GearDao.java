package com.cg.dao;

import java.util.List;

import com.cg.dto.Gear;




public interface GearDao {
	public void updateDetails(Gear gear);
	public Gear getDetail(Gear gear);
	public List<Gear> getQueryId(int qId);
}
