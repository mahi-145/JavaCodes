package com.cg.frs.dao;

import java.util.ArrayList;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;

public interface IFlatRegistrationDAO 
{
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat_Registration) throws FlatRegistrationException;

	public ArrayList<Integer> getAllOwnerIds() throws FlatRegistrationException;

}
