package com.cg.frs.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;
import com.cg.frs.util.DBUtil;

/*
 * Author		: Kapil Garg
 * Employee Id	: 137648
 * Date			: 26/10/2017
 * Description	: Method to insert the flat registration details in the database
*/

public class FlatRegistrationDAOImpl implements IFlatRegistrationDAO,IFlatRegistrationQueries 
{
	private ArrayList<Integer> ownerId;
	
	static Logger myLogger = Logger.getLogger(FlatRegistrationDAOImpl.class.getName());

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat_Registration) throws FlatRegistrationException 
	{
		myLogger.info("trying to register a flat.");
		
		try (Connection connection = DBUtil.getConnection()) 
		{
			PreparedStatement preparedStatement = connection.prepareStatement(INSERT_FLAT_REGISTER_QUERY);
			
			flat_Registration.setRegNumber(generateRegNumber());
			
			preparedStatement.setLong(1, flat_Registration.getRegNumber());
			preparedStatement.setInt(2, flat_Registration.getOwnerId());
			preparedStatement.setInt(3, flat_Registration.getFlatType());
			preparedStatement.setInt(4, flat_Registration.getFlatArea());
			preparedStatement.setDouble(5, flat_Registration.getRentAmount());
			preparedStatement.setDouble(6, flat_Registration.getDepositAmount());
			
			ResultSet resultSet = preparedStatement.executeQuery();
			
			if (resultSet.next() == false)
			{
				throw new Exception("Could not add details to database");
			}	
		
		} 
		catch (Exception e) 
		{
			myLogger.error(e.getMessage());
			
			throw new FlatRegistrationException(e.getMessage());
		}
		
		return flat_Registration;
	}

	/*
	 * Author		: Kapil Garg
	 * Employee Id	: 137648
	 * Date			: 26/10/2017
	 * Description	: Method to generate the flat registration number 
	*/
	private long generateRegNumber() throws FlatRegistrationException 
	{
		myLogger.info("trying to generate flat reg number");
		
		long id = 0;
		
		try (Connection con = DBUtil.getConnection()) 
		{
			Statement statement = con.createStatement();
			
			ResultSet resultSet = statement.executeQuery(GENERATE_FLAT_REG_ID_QUERY);
			
			if (resultSet.next() == false) 
			{
				throw new Exception("Failed to generate flat regestration id");
			}
			
			id = resultSet.getLong(1);
		} 
		catch (Exception e) 
		{
			myLogger.error(e.getMessage());
			
			throw new FlatRegistrationException(e.getMessage());
		}
		
		return id;
	}

	/*
	 * Author		: Kapil Garg
	 * Employee Id	: 137648
	 * Date			: 26/10/2017
	 * Description	: Method to verify existing owner id
	*/
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegistrationException 
	{
		myLogger.info("trying to get existing owners from the database");
		
		try (Connection con = DBUtil.getConnection()) 
		{
			Statement statement = con.createStatement();
			
			ResultSet resultSet = statement.executeQuery(GET_EXISTING_OWNER_IDS_QUERY);
			
			ownerId = new ArrayList<Integer>();
			
			while (resultSet.next()) 
			{
				int id = resultSet.getInt(1);
				ownerId.add(id);
			}
		}
		catch (Exception e) 
		{
			myLogger.error(e.getMessage());
		
			throw new FlatRegistrationException(e.getMessage());
		}
		
		return ownerId;
	}

}
