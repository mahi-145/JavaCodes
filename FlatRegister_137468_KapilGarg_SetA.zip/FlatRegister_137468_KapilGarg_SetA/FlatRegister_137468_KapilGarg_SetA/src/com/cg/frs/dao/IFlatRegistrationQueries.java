package com.cg.frs.dao;

public interface IFlatRegistrationQueries 
{
	String GENERATE_FLAT_REG_ID_QUERY ="select FLAT_SEQ.nextval from dual";
	
	String GET_EXISTING_OWNER_IDS_QUERY= "select owner_id from FLAT_OWNERS";


	String INSERT_FLAT_REGISTER_QUERY = "insert into Flat_Registration values(?,?,?,?,?,?)";

}
