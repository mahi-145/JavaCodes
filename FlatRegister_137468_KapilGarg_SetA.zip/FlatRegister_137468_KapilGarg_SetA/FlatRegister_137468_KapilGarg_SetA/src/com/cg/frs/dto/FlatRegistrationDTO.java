package com.cg.frs.dto;

public class FlatRegistrationDTO 
{
	/***** Variable declaration *****/
	private long regNumber;
	private int ownerId;
	private int flatType;
	private int flatArea;
	private double rentAmount;
	private double depositAmount;

	/***** Constructor using SuperClass *****/
	public FlatRegistrationDTO() 
	{
		super();
	}

	/***** Constructor using all parameters except regNumber *****/
	public FlatRegistrationDTO(int ownerId, int flatType, int flatArea, double rentAmount, double depositAmount) 
	{
		super();
		
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}

	/***** Constructor using all parameters *****/
	public FlatRegistrationDTO(long regNumber, int ownerId, int flatType, int flatArea, double rentAmount, double depositAmount) 
	{
		super();
		this.regNumber = regNumber;
		this.ownerId = ownerId;
		this.flatType = flatType;
		this.flatArea = flatArea;
		this.rentAmount = rentAmount;
		this.depositAmount = depositAmount;
	}

	/***** Getters and Setters for regNumber *****/
	public long getRegNumber() 
	{
		return regNumber;
	}
	public void setRegNumber(long regNumber) 
	{
		this.regNumber = regNumber;
	}

	/***** Getters and Setters for ownerId *****/
	public int getOwnerId() 
	{
		return ownerId;
	}
	public void setOwnerId(int ownerId) 
	{
		this.ownerId = ownerId;
	}

	/***** Getters and Setters for flatType *****/
	public int getFlatType() 
	{
		return flatType;
	}
	public void setFlatType(int flatType) 
	{
		this.flatType = flatType;
	}

	/***** Getters and Setters for flatArea *****/
	public int getFlatArea() 
	{
		return flatArea;
	}
	public void setFlatArea(int flatArea) 
	{
		this.flatArea = flatArea;
	}

	/***** Getters and Setters for rentAmount *****/
	public double getRentAmount() 
	{
		return rentAmount;
	}
	public void setRentAmount(double rentAmount) 
	{
		this.rentAmount = rentAmount;
	}

	/***** Getters and Setters for depositAmount *****/
	public double getDepositAmount() 
	{
		return depositAmount;
	}
	public void setDepositAmount(double depositAmount) 
	{
		this.depositAmount = depositAmount;
	}
}