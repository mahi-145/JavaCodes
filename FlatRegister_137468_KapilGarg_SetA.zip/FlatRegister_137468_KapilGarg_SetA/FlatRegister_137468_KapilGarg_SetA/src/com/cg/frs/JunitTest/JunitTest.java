package com.cg.frs.JunitTest;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class JunitTest 
{
	private static IFlatRegistrationService flatRegisterService;

	@BeforeClass
	public static void init() 
	{
		flatRegisterService = new FlatRegistrationServiceImpl();
	}

	@AfterClass
	public static void cleanup() 
	{
		flatRegisterService = null;
		
		System.gc();
	}

	@Test
	public void testRegister() throws FlatRegistrationException 
	{
		FlatRegistrationDTO result;
		FlatRegistrationDTO dto = new FlatRegistrationDTO(2, 1, 650, 7000,25000);
		
		result = flatRegisterService.registerFlat(dto);
		assertNotNull(result);
	}

	@Test(expected = FlatRegistrationException.class)
	public void testRegister1() throws FlatRegistrationException 
	{
		FlatRegistrationDTO dto = new FlatRegistrationDTO();
		
		flatRegisterService.registerFlat(dto);
	}

}
