package com.cg.frs.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ValidationUtil 
{
	public static boolean isOwnerIdInvalid(int id, ArrayList<Integer> ids) 
	{
		Iterator<Integer> it = ids.iterator();
		while (it.hasNext()) 
		{
			if (id == it.next()) 
			{
				return false;
			}
		}
		
		return true;
	}

	public static boolean isFlatTypeInvalid(String flatType) 
	{
		Pattern pattern = Pattern.compile("^[1]$|^[2]$");
		Matcher matcher = pattern.matcher(flatType);
		
		if (matcher.find())
			return false;
	
		return true;
	}

	public static boolean isFlatAreaInvalid(String flatArea) 
	{
		Pattern pattern = Pattern.compile("^[1-9][0-9]*$");
		Matcher matcher = pattern.matcher(flatArea);
	
		if (matcher.find())
			return false;
		
		return true;
	}

	public static boolean isRentAmountInvalid(String rentAmount) 
	{
		Pattern pattern = Pattern.compile("^[1-9][0-9.]*$");
		Matcher matcher = pattern.matcher(rentAmount);
	
		if (matcher.find())
			return false;
		
		return true;
	}

	public static boolean isDepositAmountInvalid(double rentAmount, String depositAmount) 
	{
		Pattern pattern = Pattern.compile("^[1-9][0-9.]*$");
		Matcher matcher = pattern.matcher(depositAmount);
	
		if (matcher.find() && Double.parseDouble(depositAmount) >= rentAmount)
			return false;
		
		return true;
	}
}