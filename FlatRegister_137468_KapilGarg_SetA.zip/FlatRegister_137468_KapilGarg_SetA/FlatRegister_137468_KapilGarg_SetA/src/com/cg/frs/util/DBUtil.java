package com.cg.frs.util;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBUtil 
{
	public static Connection getConnection() throws SQLException, ClassNotFoundException, IOException 
	{
		Connection con = null;
		
		Properties prop = loadDBProperties();
		
		Class.forName(prop.getProperty("driver"));
		
		con = DriverManager.getConnection(prop.getProperty("url"), prop.getProperty("username"), prop.getProperty("password"));
		return con;
	}

	public static Properties loadDBProperties() throws IOException 
	{
		String path = "Database.properties";
		
		InputStream propsFile = null;
		
		Properties dbProperties = new Properties();
		propsFile = new FileInputStream(path);
		dbProperties.load(propsFile);
		propsFile.close();
		
		return dbProperties;
	}
}
