package com.cg.frs.service;

import java.util.ArrayList;

import com.cg.frs.dao.FlatRegistrationDAOImpl;
import com.cg.frs.dao.IFlatRegistrationDAO;
import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.exception.FlatRegistrationException;

/*
 * Author		: Kapil Garg
 * Employee Id	: 137648
 * Date			: 26/10/2017
 * Description	: To call services provided by DAO class
*/
public class FlatRegistrationServiceImpl implements IFlatRegistrationService 
{
	IFlatRegistrationDAO flatRegisterDaoObj;

	public FlatRegistrationServiceImpl() 
	{
		flatRegisterDaoObj = new FlatRegistrationDAOImpl();
	}

	@Override
	public FlatRegistrationDTO registerFlat(FlatRegistrationDTO flat_Registration) throws FlatRegistrationException 
	{
		return flatRegisterDaoObj.registerFlat(flat_Registration);
	}

	@Override
	public ArrayList<Integer> getAllOwnerIds() throws FlatRegistrationException 
	{
		return flatRegisterDaoObj.getAllOwnerIds();
	}
	
}
