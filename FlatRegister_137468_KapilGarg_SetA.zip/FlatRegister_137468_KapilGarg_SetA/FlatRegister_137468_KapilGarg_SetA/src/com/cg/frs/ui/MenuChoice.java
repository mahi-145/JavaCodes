package com.cg.frs.ui;

public interface MenuChoice 
{
	public int REGISTER_FLAT = 1;
	
	public int EXIT_APPLICATION = 2;
}
