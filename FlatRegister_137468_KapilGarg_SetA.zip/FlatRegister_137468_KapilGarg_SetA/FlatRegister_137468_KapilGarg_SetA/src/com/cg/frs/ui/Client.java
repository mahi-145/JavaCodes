package com.cg.frs.ui;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.frs.dto.FlatRegistrationDTO;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;
import com.cg.frs.util.ValidationUtil;

public class Client implements MenuChoice 
{
	IFlatRegistrationService flatRegisterService;

	private Scanner scanner = new Scanner(System.in);

	public Client() 
	{
		flatRegisterService = new FlatRegistrationServiceImpl();
	}

	public void menu() 
	{
		System.out.println("################# Flat Register #################");
		System.out.println("\n1) Register Flat");
		System.out.println("2) Exit\n");
		System.out.println("Select an option from the above list:");
		
		int choice = scanner.nextInt();
		
		switch (choice) 
		{
			case REGISTER_FLAT:
				registerFlat();
				break;
	
			case EXIT_APPLICATION:
				System.out.println("Thank you for using FlatRegistration_137468_KapilGarg_SetA Application.");
				System.exit(0);
	
			default:
				System.out.println("Please choose correct choice");
				break;
		}
	}

	private void registerFlat() 
	{
		ArrayList<Integer> ids = null;
		
		try 
		{
			ids = flatRegisterService.getAllOwnerIds();
		
			System.out.print("\nExisting Owner IDS Are:{ ");
			
			Iterator<Integer> it = ids.iterator();
			
			while (it.hasNext())
			{
				System.out.print(it.next() + " ");
			}
			
			System.out.println("}\n");
		} 
		catch (Exception e) 
		{
			System.out.println("Something went wrong while trying to get existing owner Id's. Exact Reason "+ e.getMessage());
		}
		
		int id = 0;
		
		boolean status = false;
		
		do 
		{
			if (status) 
			{
				System.out.println("\nOwner does not Exists\n");
			}
			
			System.out.print("Please enter your owner id from above list:");
			
			id = scanner.nextInt();
		
		} while (status = ValidationUtil.isOwnerIdInvalid(id, ids));
		
		int flatType = 0;
		
		do 
		{
			if (status) 
			{
				System.out.println("Select appropriate Flat Type");
			}
			
			System.out.print("Select Flat Type (1-BHK, 2-2BHK):");
			
			flatType = scanner.nextInt();
		
		} while (status = ValidationUtil.isFlatTypeInvalid(flatType + ""));
		
		int flatArea = 0;
		
		do 
		{
			if (status) 
			{
				System.out.println("Provide valid Flat area");
			}
			
			System.out.print("Enter Flat area in sq. ft.:");
			
			flatArea = scanner.nextInt();
		
		} while (status = ValidationUtil.isFlatAreaInvalid(flatArea + ""));
		
		double rentAmount = 0;
		
		do 
		{
			if (status) 
			{
				System.out.println("Provide valid rent amount");
			}
			
			System.out.print("Enter desired rent amount Rs:");
			
			rentAmount = scanner.nextDouble();
		
		} while (status = ValidationUtil.isRentAmountInvalid(rentAmount + ""));
		
		double depositAmount = 0;
		
		do {
			if (status)
			{
				System.out.println("desired amount should be greather than rent amount");
			}
			
			System.out.print("Enter desired deopist amount Rs: ");
			
			depositAmount = scanner.nextDouble();
		
		} while (status = ValidationUtil.isDepositAmountInvalid(rentAmount, depositAmount + ""));
		
		FlatRegistrationDTO flat_Registration = new FlatRegistrationDTO(id, flatType, flatArea, rentAmount, depositAmount);
		
		try 
		{
			FlatRegistrationDTO flatRegistered = flatRegisterService.registerFlat(flat_Registration);
			System.out.println("\nFlat Successfully registered. Registration id: " + flatRegistered.getRegNumber() + "\n");
		} 
		catch (Exception e) 
		{
			System.out.println("Somthing went wrong while trying to register a flat. Exact Reason "+ e.getMessage());
		}
	}

	public static void main(String[] args) 
	{
		PropertyConfigurator.configure("log4j.properties");
		
		Client flatRegisterUI = new Client();
		
		while (true) 
		{
			flatRegisterUI.menu();
		}
	}
}