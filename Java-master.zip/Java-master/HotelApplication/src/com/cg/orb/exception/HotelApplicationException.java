package com.cg.orb.exception;

public class HotelApplicationException extends Exception{

	public HotelApplicationException(String msg) {

		super(msg);
	}

	
}
