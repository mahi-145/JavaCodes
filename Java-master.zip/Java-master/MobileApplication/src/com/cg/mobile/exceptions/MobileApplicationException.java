package com.cg.mobile.exceptions;

public class MobileApplicationException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	
	public MobileApplicationException(String msg){
			super(msg);
	}

}
