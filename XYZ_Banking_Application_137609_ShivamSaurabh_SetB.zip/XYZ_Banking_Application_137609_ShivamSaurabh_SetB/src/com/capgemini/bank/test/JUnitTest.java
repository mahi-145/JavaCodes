package com.capgemini.bank.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class JUnitTest {

	
	private static IDemandDraftService service;
	@BeforeClass
	public void init()
	{
		service=new DemandDraftService();	
	}
	
	@AfterClass
	public void clean()
	{
		service=null;
		System.gc();
	}
	
	@Test
	public void testAddDemandDraftDetails() 
	{
		
	}

}