package com.capgemini.bank.ui;

public interface IMenu 
{
		int DEMAND_DRAFT_DETAILS = 1;
		int PRINT_DETAILS = 2;
		int EXIT = 3;
}