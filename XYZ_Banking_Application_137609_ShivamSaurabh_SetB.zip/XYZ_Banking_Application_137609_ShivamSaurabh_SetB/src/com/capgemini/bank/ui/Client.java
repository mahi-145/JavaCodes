package com.capgemini.bank.ui;

import java.util.Scanner;
import org.apache.log4j.PropertyConfigurator;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;
import com.capgemini.bank.util.validation;


public class Client implements IMenu 
{
	private IDemandDraftService service;
	validation validate = new validation();

	public Client() 
	{
		service = new DemandDraftService();
	}

	private void menuOption() 
	{

		System.out.println("1) Enter Demand Draft Details");
		System.out.println("2) Print Demand Draft");
		System.out.println("3) Exit");
		Scanner scanner = new Scanner(System.in);
		int choice = scanner.nextInt();

		switch (choice) {
		case DEMAND_DRAFT_DETAILS:
			enter_details();
			break;
		case PRINT_DETAILS:
			get_details();
			break;

		case EXIT:
			System.exit(0);
		default:
			System.out.println("Enter valid Option");

		}

	}

	private void enter_details() 
	{

		Scanner scanner = new Scanner(System.in);
		
		String name = null;
		do 
		{
			System.out.println("Enter the name of the Customer:");
			name = scanner.next();
		} while (!validate.isNameValid(name));
		
		String phNo = null;
		do 
		{
			System.out.println("Enter Customer phone number:");
			phNo = scanner.next();
		} while (!validate.isPhNoValid(phNo));
		
		String favor = null;
		do 
		{
			System.out.println("In Favor of:");
			favor = scanner.next();
		} while (!validate.isfavorValid(favor));
		
		int amount = 0;
		do 
		{
			System.out.println("Enter demand Draft amount(in Rs):");
			amount = scanner.nextInt();
		} while (!validate.isAmountValid(amount));
		
		String desc = null;
		do 
		{
			System.out.println("Enter Remarks:");
			desc = scanner.next();
			desc += scanner.nextLine();
		} while (!validate.isDescValid(desc));
		
		int commission = getCommission(amount);
		DemandDraft demand = new DemandDraft(name, favor, phNo, amount, commission, desc);

		try 
		{
			int id = service.addDemandDraftDetails(demand);
			System.out.println("Your Demand Draft request has been succesfully registered along with the id "+id);

		} 
		catch (Exception e) 
		{

			System.out.println("Something went wrong while adding details resaon" + e.getMessage());

		}

	}

	private int getCommission(int amount)
	{

		if (amount <= 5000)
			amount = 10;
		else if (amount > 5000 && amount <= 10000)
			amount = 41;
		else if (amount > 10000 && amount <= 100000)
			amount = 51;
		else if (amount > 100000)
			amount = 306;
		return amount;
	}

	private void get_details() 
	{

		Scanner scanner = new Scanner(System.in);

		int id = 0;
		do 
		{
			System.out.println("Enter TransactionId");
			id = scanner.nextInt();
		} while (validate.isTransactionIdValid(id));

		try
		{

			DemandDraft demandDraft = service.getDemandDraftDetails(id);
			System.out.println("Name of the bank : XYZ");
			System.out.println("DD Amount        : " + demandDraft.getAmount());
			System.out.println("DD Commision     : " + demandDraft.getCommission());
			System.out.println("Total Amount     : " + (demandDraft.getAmount()+demandDraft.getCommission()));
			System.out.println("Transaction Date : " + demandDraft.getDate());
			System.out.println("Remarks          : " + demandDraft.getDescription());
		}

		catch (Exception e) 
		{	
			System.out.println(e.getMessage());
		}

	}
	
	public static void main(String[] args) 
	{
		PropertyConfigurator.configure("log4j.properties");
		Client client = new Client();
			client.menuOption();
	}
}