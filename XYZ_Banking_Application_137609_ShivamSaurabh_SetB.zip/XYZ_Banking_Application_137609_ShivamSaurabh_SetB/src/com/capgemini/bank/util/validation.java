package com.capgemini.bank.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class validation 
{

	public boolean isNameValid(String name) 
	{

		Pattern p1 = Pattern.compile("[a-zA-z]+$");
		Matcher m1 = p1.matcher(name);

		if (!m1.find())
		{
			return false;
		}
		return true;
	}

	public boolean isPhNoValid(String phNo) 
	{
		Pattern p1 = Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher m1 = p1.matcher(phNo);
		if (!m1.find()) 
		{
			return false;
		}
		return true;

	}

	public boolean isfavorValid(String favor) 
	{

		Pattern p1 = Pattern.compile("[a-zA-z]+$");
		Matcher m1 = p1.matcher(favor);

		if (!m1.find()) 
		{
			return false;
		}
		return true;
	}

	public boolean isAmountValid(int amount) 
	{

		if (amount <= 0)
			return false;
		return true;

	}
	public boolean isDescValid(String desc)
	{

		Pattern p1 = Pattern.compile("[a-zA-z ]+$");
		Matcher m1 = p1.matcher(desc);

		if (!m1.find()) {
			return false;
		}
		return true;
	}

	public boolean isTransactionIdValid(int id)
	{
		if(id>0)
		return false;
		return true;
	}
}