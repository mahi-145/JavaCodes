package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankException;

public interface IDemandDraftService 
{	
	int addDemandDraftDetails(DemandDraft demandDraft) throws BankException;
	
	DemandDraft getDemandDraftDetails(int transactionId) throws BankException;
}