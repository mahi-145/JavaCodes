package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.dao.IDemandDraftDAO;
import com.capgemini.bank.exception.BankException;

public class DemandDraftService implements IDemandDraftService 
{

	IDemandDraftDAO demandDraftservice;
	
	public DemandDraftService()
	{
		demandDraftservice=new DemandDraftDAO();
	}
	
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws BankException 
	{
		return demandDraftservice.addDemandDraftDetails(demandDraft);
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankException 
	{
		return demandDraftservice.getDemandDraftDetails(transactionId);
	}

}