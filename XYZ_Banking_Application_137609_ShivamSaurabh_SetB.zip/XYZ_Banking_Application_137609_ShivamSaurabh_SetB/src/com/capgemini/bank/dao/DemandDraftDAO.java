package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.BankException;
import com.capgemini.bank.util.DBUtil;

public class DemandDraftDAO implements IDemandDraftDAO, DAOQueries 
{

	/*
	 * Author: Shivam Saurabh
	 * Employee Id: 137609
	 * Date	:26/10/2017 
	 * Description: Take Demand Draft Details From User And Display The Details
	 * 
	 */
	
	static Logger myLogger = Logger.getLogger(DemandDraftDAO.class.getName());

	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws BankException 
	{

		////Insert Demand Draft Details

		myLogger.info("addDemandDraftDetails Method started");
		
		int id = 0;
		try (Connection con = DBUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement(INSERT_DEMAND_DRAFT_VALUES);

			demandDraft.setTransactionId(generateTransactionId());
			pstm.setInt(1, demandDraft.getTransactionId());
			pstm.setString(2, demandDraft.getCname());
			pstm.setString(3, demandDraft.getInFavorOf());
			pstm.setString(4, demandDraft.getPhNo());
			pstm.setInt(5, demandDraft.getAmount());
			pstm.setInt(6, demandDraft.getCommission());
			pstm.setString(7, demandDraft.getDescription());

			pstm.execute();

			id = demandDraft.getTransactionId();

		} 
		catch (Exception e) 
		{
			throw new BankException(e.getMessage());
		}
		return id;
	}

	private int generateTransactionId() 
	{
	////Generate Transaction Id 

		myLogger.info("generateTransactionId Method started");
		myLogger.debug("Trying to generate Transactionid from sequence");

		int id = 0;

		try (Connection con = DBUtil.getConnection()) 
		{

			Statement stn = con.createStatement();
			ResultSet res = stn.executeQuery(GENERATE_ID);
			if (res.next() == false) {

				
				myLogger.error("Couldnt create Transaction id");
				throw new Exception("Could not generate id");

			}
			id = res.getInt(1);
		} 
		catch (Exception e)
		{
			
		}
		return id;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankException 
	{
	
		////Display Demand Draft Details

		myLogger.info("getDemandDraftDetails Method started");
		DemandDraft demandDraft = null;

		try (Connection con = DBUtil.getConnection()) 
		{

			PreparedStatement pstm = con.prepareStatement(FETCH);
			pstm.setInt(1, transactionId);
			ResultSet rs = pstm.executeQuery();

			if (rs.next() == false) 
			{
				throw new Exception("Invalid Transaction Id");
			}

			demandDraft = new DemandDraft();

			demandDraft.setTransactionId(transactionId);
			demandDraft.setCname(rs.getString(2));
			demandDraft.setInFavorOf(rs.getString(3));
			demandDraft.setPhNo(rs.getString(4));
			demandDraft.setDate(rs.getDate(5));
			demandDraft.setAmount(rs.getInt(6));
			demandDraft.setCommission(rs.getInt(7));
			demandDraft.setDescription(rs.getString(8));

		}
		catch (Exception e) 
		{
			throw new BankException(e.getMessage());
		}
		return demandDraft;

	}

}
