package com.capgemini.bank.dao;

public interface DAOQueries 
{	
	String INSERT_DEMAND_DRAFT_VALUES="insert into demand_draft values(?,?,?,?,sysdate,?,?,?)";
	String FETCH="select * from demand_draft where transaction_id=?";
	String GENERATE_ID="select Transaction_id_seq.nextval from dual";	
}
