package com.cg.service;

import java.sql.SQLException;
import com.cg.dao.RegisterDao;
import com.cg.dao.RegisterDaoImpl;
import com.cg.dto.Register;

public class RegisterServiceImpl implements RegisterService
{
	RegisterDao regDao= null;
	public RegisterServiceImpl()
	{
		regDao=new RegisterDaoImpl();
	}
	
	@Override
	public int addUser(Register rg) throws SQLException 
	{
		
		return regDao.addUser(rg);
	}
	
}
