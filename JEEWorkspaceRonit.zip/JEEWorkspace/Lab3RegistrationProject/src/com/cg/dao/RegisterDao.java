package com.cg.dao;
import java.sql.SQLException;
import com.cg.dto.Register;
public interface RegisterDao
{

	public int addUser(Register rg) throws SQLException;
	
}
