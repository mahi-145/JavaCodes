package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.cg.dto.Register;
import com.cg.util.DBUtil;

public class RegisterDaoImpl implements RegisterDao
{

	Connection con=null;
	Statement st=null;
	ResultSet rs=null;
	PreparedStatement pst=null;

	@Override
	public int addUser(Register rg) throws SQLException 
	{
		String qry="Insert into registeredusers values(?,?,?,?,?.?)";
		int UserAdded=0;


		con=DBUtil.getCon();
		pst=con.prepareStatement(qry);
		pst.setString(1, rg.getFirstName());
		pst.setString(2, rg.getLastName());
		pst.setString(3, rg.getPassword());
		pst.setString(4, String.valueOf(rg.getGender()));
		pst.setString(5, rg.getSkillset());
		pst.setString(6, rg.getCity());

		UserAdded=pst.executeUpdate();
		return UserAdded;

	}

}



