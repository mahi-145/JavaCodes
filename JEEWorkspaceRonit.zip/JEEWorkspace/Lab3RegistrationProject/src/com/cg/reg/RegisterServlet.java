package com.cg.reg;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Register;
import com.cg.service.RegisterService;
import com.cg.service.RegisterServiceImpl;


@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	Register rg=null;
	RegisterService regSer=null;
       
   
    public RegisterServlet() 
    {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException 
	{
	
	}

	public void destroy() 
	{
		
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String firstName=request.getParameter("firstName");
		String lastName=request.getParameter("lastName");
		String password=request.getParameter("password");
		String gender=request.getParameter("Gender");
		String skillset=request.getParameter("skill");
		String city=request.getParameter("city");
		
		regSer=new RegisterServiceImpl();
		PrintWriter pw=response.getWriter();
		rg=new Register(firstName,lastName,password,gender.charAt(0),skillset,city);
		int dataAdded=0;
		
		try
		{
			dataAdded=regSer.addUser(rg);
			if(dataAdded==1)
			{
				pw.println("Registration Successfull");
			}
			else
			{
				pw.println("Failure");
				
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
	}

}
