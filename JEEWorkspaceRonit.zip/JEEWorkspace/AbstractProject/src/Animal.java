
abstract class Animal
{
	public abstract void sound();
}

 class Lion extends Animal
{
	@Override
	public void sound()
	{
		System.out.println("ROAR");
	}
	public static void main(String args[])
	{
		Animal ob=new Lion();
		ob.sound();
	}
}
