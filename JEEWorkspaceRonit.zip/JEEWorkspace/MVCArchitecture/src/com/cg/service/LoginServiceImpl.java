package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.LoginDao;
import com.cg.dao.LoginDaoImpl;
import com.cg.dto.Login;
import com.cg.exception.LoginException;

public class LoginServiceImpl implements LoginService
{
	LoginDao logDao= null;
	public LoginServiceImpl()
	{
		logDao=new LoginDaoImpl();
	}


	@Override
	public Login getUserByUnm(String unm) throws SQLException, Exception, LoginException
	{
	
		{

			return logDao.getUserByUnm(unm);
		}
	} 
	

}

	