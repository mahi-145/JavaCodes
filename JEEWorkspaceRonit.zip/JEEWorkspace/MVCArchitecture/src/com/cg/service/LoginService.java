package com.cg.service;

import java.sql.SQLException;

import com.cg.dto.Login;
import com.cg.exception.LoginException;

public interface LoginService 
{
	public Login getUserByUnm(String unm) throws LoginException, SQLException, Exception;
}
