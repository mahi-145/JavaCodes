package com.cg.exception;

public class LoginException extends Exception
{
	public LoginException(String msg)
	{
		super(msg);
	}


	public LoginException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) 
	{
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public LoginException(String message, Throwable cause)
	{
		super(message, cause);
		
	}

	public LoginException(Throwable cause)
	{
		super(cause);
		
	}
	
	
}
