package com.cg.dao;

import java.sql.SQLException;

import com.cg.dto.Login;
import com.cg.exception.LoginException;


public interface LoginDao
{
	public Login getUserByUnm(String unm) throws SQLException, Exception, LoginException;
	
}
