package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.dto.Login;
import com.cg.exception.LoginException;
import com.cg.util.DBUtil;

public class LoginDaoImpl implements LoginDao 
{
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	@Override
	public Login getUserByUnm(String unm) throws SQLException,Exception,LoginException 
	{
		Login user=null;
		try
		{
		
			con=DBUtil.getCon();
			System.out.println(" Got connection ");
			
			String qry="Select * from User_142282 where user_id= ?";
			pst=con.prepareStatement(qry);
			pst.setString(1,unm);
			rs=pst.executeQuery();
			
			rs.next();
			user=new Login(rs.getString("user_id"),rs.getString("password"));

		}
		catch(Exception e)
		{
			throw new LoginException(e.getMessage());
		}
				
		
		
		return user;
	}
	
		
}
