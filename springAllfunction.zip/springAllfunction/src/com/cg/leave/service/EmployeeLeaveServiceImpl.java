package com.cg.leave.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.leave.bean.EmployeeDetails;
import com.cg.leave.bean.EmployeeLeaveDetails;
import com.cg.leave.dao.IEmployeeLeaveDao;

@Service("employeeleaveservice")
@Transactional
public class EmployeeLeaveServiceImpl implements IEmployeeLeaveService
{
	@Autowired
	IEmployeeLeaveDao employeeleavedao;
	
	@Override
	public List<EmployeeLeaveDetails> getLeaveDetails(int empId) 
	{
		
		return employeeleavedao.getLeaveDetails(empId);
	}

	@Override
	public List<Integer> getAll() {
		// TODO Auto-generated method stub
		return employeeleavedao.getAll();
	}

	@Override
	public boolean validateId(int id) {
		List<Integer> val=employeeleavedao.getAll();
		for(int i:val){
			if(i==id){
				return true;
			}
			
		}
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<EmployeeDetails> getId(int eId) {
		// TODO Auto-generated method stub
		return employeeleavedao.getId(eId);
	}

	@Override
	public String getName(int eId) {
		// TODO Auto-generated method stub
		return employeeleavedao.getName(eId);
	}
	


}
