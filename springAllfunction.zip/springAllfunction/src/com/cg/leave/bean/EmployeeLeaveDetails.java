package com.cg.leave.bean;



import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employee_leave_details")
public class EmployeeLeaveDetails implements Serializable
{
	@Id
	@Column(name="leave_id")
	
	private int leaveId;
	
	@Column(name="empid")
	private int empId;
	
	@Column(name="start_date")
	private String startDate;
	
	@Column(name="end_date")
	private String endDate;
	
	@Column(name="description")
	private String description;
	
	@Column(name="leaves_applied")
	private int leaves_applied;

	public int getLeaveId() {
		return leaveId;
	}

	public void setLeaveId(int leaveId) {
		this.leaveId = leaveId;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getLeaves_applied() {
		return leaves_applied;
	}

	public void setLeaves_applied(int leaves_applied) {
		this.leaves_applied = leaves_applied;
	}

	@Override
	public String toString() {
		return "EmployeeLeaveDetails [leaveId=" + leaveId + ", empId=" + empId
				+ ", startDate=" + startDate + ", endDate=" + endDate
				+ ", description=" + description + ", leaves_applied="
				+ leaves_applied + "]";
	}

	
	
	
	
	
	
}
