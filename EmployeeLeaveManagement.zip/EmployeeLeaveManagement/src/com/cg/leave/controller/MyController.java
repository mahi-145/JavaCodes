package com.cg.leave.controller;


import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.leave.bean.EmployeeDetails;
import com.cg.leave.bean.EmployeeLeaveDetails;
import com.cg.leave.service.IEmployeeLeaveService;



@Controller
public class MyController 
{
	
	@Autowired
	IEmployeeLeaveService employeeleaveservice;
	
	@RequestMapping(value="all",method=RequestMethod.GET)
	public String getAll(Model model)
	{
		model.addAttribute("myId", new EmployeeDetails());
		return "home";
		
	}
	
	@RequestMapping(value="check",method=RequestMethod.POST)
	public ModelAndView validateEmployeeId(@Valid @ModelAttribute("myId") EmployeeDetails myId,BindingResult result,@RequestParam("eId") int eId, Model model) throws Exception
	{
	//	if(employeeleaveservice.validateId(eId)){
		Integer emId=myId.getEmpId();
		List<EmployeeLeaveDetails> eList=employeeleaveservice.getLeaveDetails(myId.getEmpId());
		List<EmployeeDetails> idList=employeeleaveservice.getId(myId.getEmpId());
		try
		{
			System.out.println("Id is : "+myId);

			if(result.hasErrors())
			{
				System.out.println("hII");
				return new ModelAndView("home","myId",myId);
			}
			if(idList.size()==0)
			{
				System.out.println("are you working? yes");
				int empId = eId;
				model.addAttribute("eId",eId);
				return new ModelAndView("noIdExist","temp",idList);
				
			}	
			
			if(eList.size()==0)
			{
				System.out.println(eId);
				int empId=eId;
				model.addAttribute("eId",eId);
				String name = employeeleaveservice.getName(eId);
				model.addAttribute("name",name);
				return new ModelAndView("noLeaveFound","temp",eList);
			}
			
			
				int empId=eId;
				model.addAttribute("eId",eId);
				String name = employeeleaveservice.getName(eId);
				
				model.addAttribute("name",name);
				return new ModelAndView("viewLeaveDetails","temp",eList);

		}
		catch(Exception e)
		{
			throw new Exception("Some error occured"+e.getMessage());
		}
		
	}
/*		else{
			return new ModelAndView("nouser");
		}*/
	
	
	
	
	
	
}
	

