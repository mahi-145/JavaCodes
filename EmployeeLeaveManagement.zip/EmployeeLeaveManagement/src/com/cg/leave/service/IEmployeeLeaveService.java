package com.cg.leave.service;

import java.util.List;

import com.cg.leave.bean.EmployeeDetails;
import com.cg.leave.bean.EmployeeLeaveDetails;

public interface IEmployeeLeaveService 
{
	public List<EmployeeLeaveDetails> getLeaveDetails(int empId);
	public List<Integer> getAll();
	public boolean validateId(int id);
	public List<EmployeeDetails> getId(int eId);
	public String getName(int eId);
	
}
