package com.cg.leave.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.leave.bean.EmployeeDetails;
import com.cg.leave.bean.EmployeeLeaveDetails;

@Repository("employeeleavedao")
public class EmployeeLeaveDaoImpl implements IEmployeeLeaveDao
{
	@PersistenceContext
	EntityManager em;
	@Override
	public List<EmployeeLeaveDetails> getLeaveDetails(int empId) 
	{
		Query queryone=em.createQuery("Select e from EmployeeLeaveDetails e where empId=:eId");
		queryone.setParameter("eId", empId);
		List<EmployeeLeaveDetails> empList=queryone.getResultList();
		return empList;
	}
	
	@Override
	public List<Integer> getAll() {
		Query q2= em.createQuery("Select empid from EmployeeDetails");
		return q2.getResultList();
	}
	
	@Override
	public List<EmployeeDetails> getId(int eId) {
		Query q3= em.createQuery("Select emp from EmployeeDetails emp where empId=:eId");
		q3.setParameter("eId", eId);
		List<EmployeeDetails> idList=q3.getResultList();
		return idList;
	}

	@Override
	public String getName(int eId) {
		Query q4 = em.createQuery("Select e.empName from EmployeeDetails e where empId=:eId");
		q4.setParameter("eId", eId);
		String name = (String) q4.getSingleResult();
		return name;
	}
	


}
