package com.cg.leave.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="employee_details")
public class EmployeeDetails 
{
	@Id
	@NotNull(message="Please Do not keep it blank")
	@Column(name="empid")
	private Integer empId;
	
	@Column(name="ename")
	private String empName;
	
	@Column(name="address")
	private String empAddress;
	
	@Column(name="leaves_avail")
	private int leavesAvail;

	public Integer getEmpId() {
		return empId;
	}

	public void setEmpId(Integer empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public String getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(String empAddress) {
		this.empAddress = empAddress;
	}

	public int getLeavesAvail() {
		return leavesAvail;
	}

	public void setLeavesAvail(int leavesAvail) {
		this.leavesAvail = leavesAvail;
	}

	@Override
	public String toString() {
		return "EmployeeDetails [empId=" + empId + ", empName=" + empName
				+ ", empAddress=" + empAddress + ", leavesAvail=" + leavesAvail
				+ "]";
	}
	
	
	
	
	
}
